# Knowledge-Enhancement-Portal
This is project developed for organizational use. It contains modules such as Library Management, Student Management and Exam Seating Arrangement. It will allow administrator to arrange the examinational hall at the time of exams and to manage the student details. It will also allow librarian to manage library details. I have used HTML, CSS and JavaScript for front end development; JSP(Java Server Pages) for backend processing and MYSQL database as backend.<br/><br/><center>
  <strong>Click on image to see demo</strong><br/><br/>
[![Watch the video](https://img.youtube.com/vi/Q3z-0gBtrmg/maxresdefault.jpg)](https://youtu.be/Q3z-0gBtrmg)</center>
